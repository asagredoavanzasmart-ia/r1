import React, { useState, useRef, useEffect, Suspense } from 'react';
import { Canvas, useThree, useFrame } from '@react-three/fiber';
import { OrbitControls, useTexture, Html } from '@react-three/drei';
import * as THREE from 'three';
import { SimulationState } from '../types';
import { calculateScaleFactor, calculateRedshift, calculateTemperature, calculateUniverseAge } from '../utils/cosmology';

interface ControlsProps {
  state: SimulationState;
  setState: React.Dispatch<React.SetStateAction<SimulationState>>;
  hoverData: { z: number, T: number } | null;
  toggleContext: () => void;
  activeModal: string | null;
  setActiveModal: (modal: string | null) => void;
}

// === CONSTANTS & ASSETS ===
const PLANCK_MAP_URL = "https://apod.nasa.gov/apod/image/1303/cmbr_planck_3600.jpg";
const STRUCTURE_MAP_URL = "https://pablocarlosbudassi.com/wp-content/uploads/2024/02/ouli202020SPANISH20for20social.jpg";
const WMAP_EMBED_URL = "https://sketchfab.com/models/7721055e1800494995c15e97605d7fa8/embed?autostart=1&ui_theme=dark";
const EXPANSION_MAP_URL = "https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/Evolucion_Universo_CMB_Timeline300_no_WMAP.jpg/1200px-Evolucion_Universo_CMB_Timeline300_no_WMAP.jpg";

// Updated URL for the 360 Panorama
const CMB_PANORAMA_URL = "https://themistersbarberia.cl/wp-content/uploads/2026/02/b62b82a2-8664-40ea-b17d-deabef92472d.jpg";

type ModalType = 'PLANCK' | 'STRUCTURE' | 'WMAP' | 'EXPANSION' | 'OBSERVER_POV' | null;

// === SUB-COMPONENTS ===

// Simple Error Boundary for Three.js components
interface ErrorBoundaryProps {
  children?: React.ReactNode;
  key?: React.Key;
}

interface ErrorBoundaryState {
  hasError: boolean;
}

class TextureErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: any): ErrorBoundaryState {
    console.error("Texture loading error detected in ErrorBoundary:", error);
    return { hasError: true };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("TextureErrorBoundary caught an error", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <Html center>
          <div className="text-red-400 text-xs bg-black/80 p-4 rounded-lg border border-red-500/50 backdrop-blur text-center w-72 shadow-2xl">
             <div className="mb-2 text-3xl">⚠️</div>
             <p className="font-bold mb-1 text-sm text-red-200">Error de Carga</p>
             <p className="opacity-80 leading-tight">No se pudo cargar la imagen panorámica.</p>
          </div>
        </Html>
      );
    }
    return this.props.children;
  }
}

// 1. Tooltip Component
const InfoTooltip = ({ text }: { text: string }) => (
  <div className="group relative inline-flex ml-2 items-center justify-center translate-y-0.5">
    <div className="w-4 h-4 rounded-full border border-slate-500 text-slate-400 text-[10px] font-serif italic flex items-center justify-center cursor-help hover:text-sky-300 hover:border-sky-300 transition-colors bg-slate-800/50">
      i
    </div>
    <div className="absolute left-full top-1/2 -translate-y-1/2 ml-3 w-56 p-3 bg-slate-800/95 backdrop-blur-md border border-slate-600 rounded-md shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50 pointer-events-none">
      <p className="text-xs text-slate-200 font-sans leading-relaxed">{text}</p>
      <div className="absolute top-1/2 right-full -translate-y-1/2 border-4 border-transparent border-r-slate-600"></div>
    </div>
  </div>
);

// 2. Toggle Switch Component
const ControlItem = ({ 
  label, 
  colorClass, 
  checked, 
  onChange, 
  description 
}: { 
  label: string; 
  colorClass: string; 
  checked: boolean; 
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; 
  description: string;
}) => {
  const getColorStyles = (cls: string) => {
    if (cls.includes('sky')) return 'peer-focus:ring-sky-500 peer-checked:bg-sky-600 group-hover:text-white';
    if (cls.includes('red')) return 'peer-focus:ring-red-500 peer-checked:bg-red-600 group-hover:text-red-300';
    if (cls.includes('orange')) return 'peer-focus:ring-orange-500 peer-checked:bg-orange-600 group-hover:text-orange-300';
    if (cls.includes('blue')) return 'peer-focus:ring-blue-900 peer-checked:bg-blue-900 group-hover:text-blue-300';
    if (cls.includes('purple')) return 'peer-focus:ring-purple-900 peer-checked:bg-purple-900 group-hover:text-purple-300';
    if (cls.includes('indigo')) return 'peer-focus:ring-indigo-500 peer-checked:bg-indigo-600 group-hover:text-indigo-300';
    if (cls.includes('teal')) return 'peer-focus:ring-teal-500 peer-checked:bg-teal-600 group-hover:text-teal-300';
    if (cls.includes('emerald')) return 'peer-focus:ring-emerald-500 peer-checked:bg-emerald-600 group-hover:text-emerald-300';
    return 'peer-focus:ring-slate-500 peer-checked:bg-slate-500 group-hover:text-slate-200';
  };

  return (
    <div className="flex items-center gap-2">
      <label className="flex items-center gap-2 cursor-pointer group relative">
        <div className="relative flex items-center">
          <input 
            type="checkbox" 
            checked={checked} 
            onChange={onChange}
            className="peer sr-only"
          />
          <div className={`w-9 h-5 bg-slate-700 peer-focus:outline-none peer-focus:ring-2 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all ${getColorStyles(colorClass)}`}></div>
        </div>
        <span className={`text-xs font-medium text-slate-300 transition-colors ${colorClass.includes('sky') ? 'group-hover:text-white' : ''}`}>
          {label}
        </span>
      </label>
      
      <div className="group/tooltip relative flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4 text-slate-500 hover:text-sky-400 cursor-help transition-colors">
          <path fillRule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm11.378-3.917c-.89-.777-2.366-.777-3.255 0a.75.75 0 01-.988-1.129c1.454-1.272 3.776-1.272 5.23 0 1.513 1.324 1.513 3.518 0 4.842a3.75 3.75 0 01-.837.552c-.676.328-1.028.774-1.028 1.152v.75a.75.75 0 01-1.5 0v-.75c0-1.279 1.06-2.107 1.875-2.502.182-.088.351-.199.503-.331.83-.727.83-1.857 0-2.584zM12 18a.75.75 0 100-1.5.75.75 0 000 1.5z" clipRule="evenodd" />
        </svg>
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-2.5 bg-slate-800/95 backdrop-blur-sm text-slate-200 text-[10px] leading-relaxed rounded border border-slate-600 shadow-xl opacity-0 translate-y-2 group-hover/tooltip:opacity-100 group-hover/tooltip:translate-y-0 transition-all pointer-events-none z-50">
          {description}
          <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-600"></div>
        </div>
      </div>
    </div>
  );
};

// 3. 360 Panorama Viewer Component (R3F) - Handles Image Textures
const PanoramaSphere = ({ url }: { url: string }) => {
  // Use suspense to load image texture
  const texture = useTexture(url);

  return (
    <mesh scale={[-1, 1, 1]}>
      <sphereGeometry args={[500, 60, 40]} />
      <meshBasicMaterial map={texture} side={THREE.BackSide} toneMapped={false} />
    </mesh>
  );
};

const PanoramaViewer = ({ url }: { url: string }) => {
  return (
    <div className="w-full h-full relative bg-black group">
       <Canvas camera={{ position: [0, 0, 0.1], fov: 75 }}>
          <TextureErrorBoundary>
            <Suspense fallback={<Html center><div className="flex flex-col items-center gap-3"><div className="w-8 h-8 border-4 border-sky-500 border-t-transparent rounded-full animate-spin"></div><div className="text-white text-xs font-mono">Cargando 360°...</div></div></Html>}>
              <PanoramaSphere url={url} />
            </Suspense>
          </TextureErrorBoundary>
          <OrbitControls 
             enableZoom={false} 
             enablePan={false} 
             reverseOrbit={true} // Natural look interaction
             rotateSpeed={-0.5} 
          />
       </Canvas>
       
       <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-3 pointer-events-none">
          <span className="bg-black/60 text-white text-xs px-4 py-2 rounded-full backdrop-blur-md border border-white/10 shadow-lg">
             Arrastra para mirar alrededor
          </span>
       </div>
    </div>
  );
};

// 4. Image/Content Viewer Modal with Drag-to-Pan (Advanced Implementation)
const UniversalModal = ({ type, onClose }: { type: ModalType, onClose: () => void }) => {
  // Transformation state
  const [scale, setScale] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  
  // Dragging state
  const [isDragging, setIsDragging] = useState(false);
  const [startPan, setStartPan] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  const isImage = type === 'PLANCK' || type === 'STRUCTURE' || type === 'EXPANSION';
  const isPanorama = type === 'OBSERVER_POV';
  
  // Modal Data Config
  const config = {
    PLANCK: {
      title: "Foto Fondo Cósmico de Microondas",
      subtitle: "ESA / Planck Collaboration",
      desc: "Las zonas rojas/azules muestran fluctuaciones de temperatura de ±0.0002 K. Semillas de la estructura cósmica actual.",
      src: PLANCK_MAP_URL,
      external: PLANCK_MAP_URL
    },
    STRUCTURE: {
      title: "Estructura del Universo Observable",
      subtitle: "Pablo Carlos Budassi",
      desc: "Ilustración logarítmica que muestra desde el Sistema Solar hasta el Big Bang en los bordes.",
      src: STRUCTURE_MAP_URL,
      external: STRUCTURE_MAP_URL
    },
    WMAP: {
      title: "Fondo Microondas 3D",
      subtitle: "NASA / WMAP Science Team",
      desc: "Modelo interactivo de la esfera celeste del CMB. Puedes rotar y explorar las anisotropías en 3D.",
      src: WMAP_EMBED_URL,
      external: "https://sketchfab.com/3d-models/universe-wmap-7721055e1800494995c15e97605d7fa8"
    },
    EXPANSION: {
      title: "Diagrama Expansión del Universo",
      subtitle: "NASA / Wikimedia Commons",
      desc: "Cronología visual que ilustra la inflación cósmica, la formación del CMB y la expansión acelerada por la energía oscura.",
      src: EXPANSION_MAP_URL,
      external: EXPANSION_MAP_URL
    },
    OBSERVER_POV: {
      title: "Punto de vista del observador (360° VR)",
      subtitle: "WMAP 2010 (NASA)",
      desc: "Estás en el centro del universo observable. Esta es una proyección completa del cielo del fondo cósmico de microondas con anisotropías.",
      src: CMB_PANORAMA_URL,
      external: "https://map.gsfc.nasa.gov/media/121238/index.html"
    }
  }[type || 'PLANCK'];

  // Zoom Handler (Button/Slider)
  const handleZoom = (newScale: number) => {
    setScale(Math.max(0.5, Math.min(8, newScale)));
  };

  // Wheel Zoom (Scroll to zoom)
  const handleWheel = (e: React.WheelEvent) => {
    if (!isImage) return;
    e.preventDefault();
    const scaleAdjustment = -e.deltaY * 0.002;
    const newScale = Math.max(0.5, Math.min(8, scale + scaleAdjustment));
    setScale(newScale);
  };

  // Drag Handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    if (!isImage) return;
    e.preventDefault();
    setIsDragging(true);
    setStartPan({ x: e.clientX - position.x, y: e.clientY - position.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !isImage) return;
    e.preventDefault();
    setPosition({
      x: e.clientX - startPan.x,
      y: e.clientY - startPan.y
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Reset View
  const handleReset = () => {
    setScale(1);
    setPosition({ x: 0, y: 0 });
  };

  return (
    <div 
        className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 animate-in fade-in duration-300 p-4 md:p-8"
        onClick={onClose}
    >
        {/* Close Button */}
        <button 
            className="absolute top-4 right-4 md:top-6 md:right-6 p-2 rounded-full bg-slate-800 text-white hover:bg-slate-700 transition-colors z-50 border border-slate-700 shadow-lg"
            onClick={onClose}
        >
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
        </button>

        <div className="flex flex-col w-full h-full max-w-6xl mx-auto pointer-events-auto" onClick={(e) => e.stopPropagation()}>
            
            {/* Main Content Area */}
            <div 
                ref={containerRef}
                className="relative flex-grow bg-slate-900/50 rounded-lg overflow-hidden border border-slate-800 flex items-center justify-center select-none"
                onWheel={handleWheel}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
                style={{ cursor: isImage ? (isDragging ? 'grabbing' : 'grab') : 'default' }}
            >
                {isImage ? (
                   <div 
                      style={{ 
                          transform: `translate(${position.x}px, ${position.y}px) scale(${scale})`,
                          transition: isDragging ? 'none' : 'transform 0.1s ease-out'
                      }}
                      className="origin-center will-change-transform"
                   >
                       <img 
                          src={config.src} 
                          alt={config.title}
                          className="max-w-none max-h-[80vh] object-contain pointer-events-none shadow-2xl"
                          draggable={false}
                       />
                   </div>
                ) : isPanorama ? (
                   <PanoramaViewer url={config.src} />
                ) : (
                   <iframe 
                      title={config.title}
                      src={config.src} 
                      className="w-full h-full border-0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen; vr"
                      referrerPolicy="strict-origin-when-cross-origin"
                      allowFullScreen
                   ></iframe>
                )}

                {/* Zoom Controls (Only for Images) */}
                {isImage && (
                    <div className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-slate-900/90 backdrop-blur border border-slate-700 px-4 py-2 rounded-full flex items-center gap-4 shadow-xl z-50">
                        <button onClick={() => handleZoom(scale - 0.5)} className="text-slate-300 hover:text-white p-1 hover:bg-slate-700 rounded transition-colors">
                             <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" /></svg>
                        </button>
                        <input 
                            type="range" 
                            min="0.5" 
                            max="8" 
                            step="0.1" 
                            value={scale} 
                            onChange={(e) => handleZoom(parseFloat(e.target.value))}
                            className="w-32 h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-sky-500"
                        />
                        <button onClick={() => handleZoom(scale + 0.5)} className="text-slate-300 hover:text-white p-1 hover:bg-slate-700 rounded transition-colors">
                             <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
                        </button>
                        <div className="w-px h-4 bg-slate-700 mx-1"></div>
                        <button 
                            onClick={handleReset} 
                            className="text-[10px] font-bold text-sky-400 hover:text-white uppercase tracking-wider px-2"
                        >
                            Reset
                        </button>
                    </div>
                )}
            </div>

            {/* Footer Info */}
            <div className="mt-4 flex flex-col md:flex-row items-center justify-between gap-4 bg-slate-900/80 backdrop-blur border border-slate-700 rounded-xl p-4 shrink-0 z-50">
                 <div className="text-center md:text-left">
                    <h2 className="text-lg font-bold text-white">{config.title}</h2>
                    <p className="text-slate-400 text-xs mt-1 max-w-2xl">
                         {config.desc}
                         <span className="block mt-0.5 text-[10px] text-slate-500 uppercase tracking-widest">{config.subtitle}</span>
                    </p>
                 </div>
                 
                 <a 
                    href={config.external} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="px-6 py-2 bg-slate-800 hover:bg-sky-600 text-sky-400 hover:text-white border border-slate-700 hover:border-sky-500 rounded-lg text-sm font-bold transition-all shadow-lg flex items-center gap-2 whitespace-nowrap"
                 >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
                    Ver Fuente Original
                 </a>
            </div>
        </div>
    </div>
  );
};

// === MAIN COMPONENT ===

const Controls: React.FC<ControlsProps> = ({ state, setState, hoverData, toggleContext, activeModal, setActiveModal }) => {
  // const [activeModal, setActiveModal] = useState<ModalType>(null); // MOVED TO APP
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const speedOptions = [0.25, 0.5, 1, 2, 3];
  
  const handleTimelineChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setState(prev => ({ ...prev, time: parseFloat(e.target.value), isPlaying: false }));
  };

  const handleZoomChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setState(prev => ({ ...prev, zoomLevel: parseFloat(e.target.value) }));
  };

  const adjustZoom = (delta: number) => {
    setState(prev => {
      const newValue = Math.max(5, Math.min(80, prev.zoomLevel + delta));
      return { ...prev, zoomLevel: newValue };
    });
  };

  const togglePlay = () => {
    if (state.time >= 1) {
      setState(prev => ({ ...prev, time: 0, isPlaying: true }));
    } else {
      setState(prev => ({ ...prev, isPlaying: !prev.isPlaying }));
    }
  };

  const changeSpeed = (speed: number) => {
    setState(prev => ({ ...prev, playbackSpeed: speed }));
    setShowSpeedMenu(false);
  };

  const currentScale = calculateScaleFactor(state.time);
  const currentZ = calculateRedshift(currentScale);
  const currentT = calculateTemperature(currentZ);
  const ageString = calculateUniverseAge(state.time);

  const displayZ = hoverData && hoverData.z > 0 ? hoverData.z : currentZ;
  const displayT = hoverData && hoverData.T > 0 ? hoverData.T : currentT;

  const isFinished = state.time >= 1;

  // Calculate Zoom Percentage for Display
  const zoomPercentage = Math.round(((80 - state.zoomLevel) / (80 - 5)) * 100);

  // Timeline Markers Configuration
  const eventMarkers = [
    { pos: 0, label: 'Recombinación', major: true, offsetClass: 'mb-10' },
    { pos: 3, label: '1ras Estrellas', offsetClass: 'mb-0' },
    { pos: 10, label: 'Galaxias', offsetClass: 'mb-4' },
    { pos: 36, label: 'Vía Láctea', offsetClass: 'mb-0' },
    { pos: 67, label: 'Tierra', offsetClass: 'mb-8' },
    { pos: 100, label: 'Presente', major: true, offsetClass: 'mb-0' },
  ];

  // Year ticks (Bottom of slider) - UPDATED TO NEW FORMAT
  const yearTicks = [
    { pos: 0, label: '380k' },
    { pos: 10, label: '1.300 M' },
    { pos: 36, label: '5.000 M' },
    { pos: 72, label: '10.000 M' },
    { pos: 100, label: '13.800 M' },
  ];

  return (
    <>
      <div className="absolute inset-0 pointer-events-none z-10">
        
        {/* 1. SIDEBAR ZOOM CONTROL */}
        <div id="tour-zoom" className="absolute right-6 top-1/2 -translate-y-1/2 pointer-events-auto flex flex-col items-center bg-slate-900/80 backdrop-blur-md border border-slate-700 rounded-full py-4 shadow-2xl transition-transform hover:scale-105 group">
          <button 
            onClick={() => adjustZoom(-5)} 
            className="p-2 text-slate-300 hover:text-white hover:bg-slate-700 rounded-full transition-colors mb-2"
            title="Acercar"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
          </button>
          
          <div className="h-32 w-8 flex items-center justify-center relative">
             <input 
                type="range" 
                min="5" 
                max="80" 
                step="0.5"
                value={state.zoomLevel}
                onChange={handleZoomChange}
                className="absolute w-32 h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-sky-500 hover:accent-sky-400 -rotate-90 origin-center"
              />
          </div>

          <button 
            onClick={() => adjustZoom(5)} 
            className="p-2 text-slate-300 hover:text-white hover:bg-slate-700 rounded-full transition-colors mt-2"
            title="Alejar"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" /></svg>
          </button>
          
          <div className="mt-3 text-[10px] font-mono text-slate-400 font-bold group-hover:text-sky-400 transition-colors">
              {zoomPercentage}%
          </div>
        </div>


        {/* 2. DATA HUD AND EXTERNAL LINKS */}
        <div className="absolute left-6 top-28 bottom-32 w-72 pointer-events-auto hidden md:flex flex-col justify-center gap-3 z-50">
          
          {/* Data Panel */}
          <div id="tour-data" className="bg-slate-900/80 backdrop-blur-md border border-slate-700 p-5 rounded-lg text-white shadow-xl w-full">
            <h3 className="text-xs uppercase tracking-wider text-slate-400 mb-5 border-b border-slate-700 pb-2 flex justify-between items-center">
              Datos en Tiempo Real
              <div className="flex items-center gap-2 bg-slate-800 px-2 py-1 rounded-full border border-slate-700">
                  <div className={`w-2 h-2 rounded-full transition-all duration-300 ${state.isPlaying ? 'bg-green-500 shadow-[0_0_8px_#22c55e] animate-pulse' : 'bg-slate-600'}`}></div>
                  <span className={`text-[9px] font-bold ${state.isPlaying ? 'text-green-400' : 'text-slate-500'}`}>Live</span>
              </div>
            </h3>
            
            <div className="flex justify-between items-end mb-5">
              <div className="flex items-center">
                  <span className="text-slate-300 font-medium">Redshift (z)</span>
                  <InfoTooltip text="Mide cuánto se ha 'estirado