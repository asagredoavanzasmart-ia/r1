import React, { useMemo, useRef, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Text, Billboard, Html } from '@react-three/drei';
import * as THREE from 'three';
import { calculateScaleFactor, calculateRedshift, calculateTemperature, getPhotonColor } from '../utils/cosmology';
import { SimulationState } from '../types';

// Constants for the simulation scale
const INITIAL_UNIVERSE_RADIUS = 5;
const MAX_EXPANSION_SCALE = 30; // The outer edge will grow 30x
const PHOTON_COUNT = 800;

interface SimulationProps {
  state: SimulationState;
  onHoverData: (z: number, T: number) => void;
  onZoomChange?: (zoom: number) => void;
  onOpen360: () => void;
}

// === Geodesic Spacetime Fabric (Icosahedral Projection) ===
// Implementation based on: Solid Armillary Sphere / Icosahedral Geodesic Projection
// Non-Linear Radial Progression: ri = R * (i/N)^p
const GeodesicMetricGrid: React.FC<{ 
  progress: number; 
  initialRadius: number; 
  show: boolean; 
}> = ({ progress, initialRadius, show }) => {
  // Parameters derived from the prompt description
  const numLayers = 8; // N
  const radialPower = 2.2; // p > 1.0 (Non-linear growth, dense center)
  const detail = 1; // Icosahedron subdivision (Geodesic Frequency f)
  
  // Calculate expansion factor based on progress (same logic as other fabrics)
  const geometricBase = 2.2; 
  const frequencyDivisor = 1.5;
  const edgeTerm = Math.pow(geometricBase, initialRadius / frequencyDivisor) - 1;
  // This matches the `visualGrowth` calculation in SceneContent
  const expansionFactor = 1 + progress * edgeTerm * 1.5;

  // 1. Generate Base Icosahedron Geometry (Normalized radius 1)
  const baseGeometry = useMemo(() => {
    return new THREE.IcosahedronGeometry(1, detail);
  }, [detail]);

  // 2. Extract Vertices for Radial Struts
  const strutVertices = useMemo(() => {
    const positionAttribute = baseGeometry.getAttribute('position');
    const vertices: THREE.Vector3[] = [];
    const uniqueMap = new Set(); // Simple dedup

    for (let i = 0; i < positionAttribute.count; i++) {
        const v = new THREE.Vector3().fromBufferAttribute(positionAttribute, i);
        const key = `${v.x.toFixed(3)},${v.y.toFixed(3)},${v.z.toFixed(3)}`;
        if (!uniqueMap.has(key)) {
            uniqueMap.add(key);
            vertices.push(v);
        }
    }
    return vertices;
  }, [baseGeometry]);

  // 3. Create Line Segments for Radial Struts
  // Lines go from Origin (0,0,0) to Surface Direction
  const strutGeometry = useMemo(() => {
    const points: number[] = [];
    strutVertices.forEach(v => {
        points.push(0, 0, 0); // Start
        points.push(v.x, v.y, v.z); // End (Normalized Direction)
    });
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(points, 3));
    return geo;
  }, [strutVertices]);

  // Refs for animation
  const layersRef = useRef<THREE.Group>(null);
  const strutsRef = useRef<THREE.LineSegments>(null);

  useFrame(() => {
    if (!show || !layersRef.current || !strutsRef.current) return;

    // Animate Layers (Spherical Frustums bounds)
    layersRef.current.children.forEach((mesh, i) => {
        // r_i = R * ((i+1)/N)^p
        // Scaled by the global expansion factor
        const normalizedStep = (i + 1) / numLayers;
        const radius = initialRadius * Math.pow(normalizedStep, radialPower) * expansionFactor;
        mesh.scale.setScalar(radius);
    });

    // Animate Struts (Length matches outer radius)
    const maxRadius = initialRadius * Math.pow(1, radialPower) * expansionFactor; // i=N -> 1
    
    // We scale the struts container so lines reach the outer edge
    // Note: The geometry defined lines from 0 to 1. So scaling by maxRadius makes them 0 to maxRadius.
    strutsRef.current.scale.setScalar(maxRadius);
  });

  if (!show) return null;

  return (
    <group>
      {/* Concentric Geodesic Layers (Wireframes) */}
      <group ref={layersRef}>
        {Array.from({ length: numLayers }).map((_, i) => (
          <lineSegments key={i}>
            <wireframeGeometry args={[baseGeometry]} />
            <lineBasicMaterial 
              color="#06b6d4" // Same Cyan as Spacetime Fabric
              transparent 
              opacity={0.075} // Same low opacity
              depthWrite={false}
            />
          </lineSegments>
        ))}
      </group>

      {/* Radial Struts (Connecting Origin to Surface) */}
      <lineSegments ref={strutsRef} geometry={strutGeometry}>
        <lineBasicMaterial 
            color="#06b6d4" 
            transparent 
            opacity={0.05} // Slightly fainter struts
            depthWrite={false} 
        />
      </lineSegments>

      {/* Label */}
      <Billboard position={[initialRadius * expansionFactor, initialRadius * expansionFactor, 0]}>
         <Text fontSize={0.8} color="#06b6d4" fillOpacity={0.7} outlineWidth={0.02} outlineColor="black">
            Métrica Geodésica ($r^p$)
         </Text>
      </Billboard>
    </group>
  );
};

// === Spacetime Fabric (Geometric/Logarithmic Metric) ===
const SpacetimeFabric: React.FC<{ 
  progress: number; 
  initialRadius: number; 
  show: boolean; 
}> = ({ progress, initialRadius, show }) => {
  const lineRef = useRef<THREE.LineSegments>(null);
  
  const initialPositions = useMemo(() => {
    const points: number[] = [];
    const R = initialRadius;
    const spacing = 0.5; 

    const addLine = (x1: number, y1: number, z1: number, x2: number, y2: number, z2: number) => {
        points.push(x1, y1, z1);
        points.push(x2, y2, z2);
    };

    const range = Math.floor(R / spacing);

    for (let y = -range; y <= range; y++) {
      for (let z = -range; z <= range; z++) {
        const yPos = y * spacing;
        const zPos = z * spacing;
        if (yPos*yPos + zPos*zPos < R*R) {
           const xLimit = Math.sqrt(R*R - (yPos*yPos + zPos*zPos));
           addLine(-xLimit, yPos, zPos, xLimit, yPos, zPos);
        }
      }
    }

    for (let x = -range; x <= range; x++) {
      for (let z = -range; z <= range; z++) {
        const xPos = x * spacing;
        const zPos = z * spacing;
        if (xPos*xPos + zPos*zPos < R*R) {
           const yLimit = Math.sqrt(R*R - (xPos*xPos + zPos*zPos));
           addLine(xPos, -yLimit, zPos, xPos, yLimit, zPos);
        }
      }
    }

    for (let x = -range; x <= range; x++) {
      for (let y = -range; y <= range; y++) {
        const xPos = x * spacing;
        const yPos = y * spacing;
        if (xPos*xPos + yPos*yPos < R*R) {
           const zLimit = Math.sqrt(R*R - (xPos*xPos + yPos*yPos));
           addLine(xPos, yPos, -zLimit, xPos, yPos, zLimit);
        }
      }
    }

    return new Float32Array(points);
  }, [initialRadius]);

  const geometry = useMemo(() => {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(initialPositions), 3));
    return geo;
  }, [initialPositions]);

  useFrame(() => {
    if (!lineRef.current || !show) return;

    const positions = lineRef.current.geometry.attributes.position.array as Float32Array;
    const count = initialPositions.length / 3;

    for (let i = 0; i < count; i++) {
      const ix = i * 3;
      const iy = i * 3 + 1;
      const iz = i * 3 + 2;

      const x0 = initialPositions[ix];
      const y0 = initialPositions[iy];
      const z0 = initialPositions[iz];

      const dist = Math.sqrt(x0*x0 + y0*y0 + z0*z0);
      
      const geometricBase = 2.2; 
      const frequencyDivisor = 1.5;
      const geometricTerm = Math.pow(geometricBase, dist / frequencyDivisor) - 1;
      const expansionFactor = 1 + progress * geometricTerm * 1.5;

      positions[ix] = x0 * expansionFactor;
      positions[iy] = y0 * expansionFactor;
      positions[iz] = z0 * expansionFactor;
    }

    lineRef.current.geometry.attributes.position.needsUpdate = true;
  });

  if (!show) return null;

  return (
    <lineSegments ref={lineRef} geometry={geometry}>
      <lineBasicMaterial 
        color="#06b6d4" 
        transparent 
        opacity={0.075} 
        linewidth={1} 
        depthWrite={false}
      />
    </lineSegments>
  );
};

// === Standard CMB Photons (Successful Arrival) ===
const Photons: React.FC<{ 
  progress: number; 
  scaleFactor: number; 
  showLabels: boolean; 
  showTails: boolean; 
  showAnisotropies: boolean;
  onHover: (z: number, T: number) => void;
  onOpen360: () => void;
}> = ({ progress, scaleFactor, showLabels, showTails, showAnisotropies, onHover, onOpen360 }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const tailMeshRef = useRef<THREE.InstancedMesh>(null);
  const labelGroupRef = useRef<THREE.Group>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  
  const HERO_PHOTON_INDEX = 10;
  const isNearEnd = progress > 0.95;

  const photonData = useMemo(() => {
    const data = [];
    for (let i = 0; i < PHOTON_COUNT; i++) {
      const phi = Math.acos(-1 + (2 * i) / PHOTON_COUNT);
      const theta = Math.sqrt(PHOTON_COUNT * Math.PI) * phi;
      
      const ux = Math.sin(phi) * Math.cos(theta);
      const uy = Math.sin(phi) * Math.sin(theta);
      const uz = Math.cos(phi);

      // Anisotropy Generation (Color Data Only)
      const frequencyLow = 2.5;
      const frequencyHigh = 6.0;
      
      const structure = (
        Math.sin(ux * frequencyLow) * Math.cos(uy * frequencyLow) + 
        Math.sin(uz * frequencyLow) +
        0.5 * Math.sin(ux * frequencyHigh + uy * frequencyHigh) 
      );

      const rawNoise = (structure * 0.7) + ((Math.random() - 0.5) * 0.6);
      const anisotropy = Math.max(-1, Math.min(1, rawNoise));

      const x = INITIAL_UNIVERSE_RADIUS * ux;
      const y = INITIAL_UNIVERSE_RADIUS * uy;
      const z = INITIAL_UNIVERSE_RADIUS * uz;

      data.push({ 
          vec: new THREE.Vector3(x, y, z),
          anisotropy: anisotropy
      });
    }
    return data;
  }, []);

  const tailGeometry = useMemo(() => {
    const height = 5.25;
    const geo = new THREE.CylinderGeometry(0, 0.4, height, 8);
    geo.rotateX(-Math.PI / 2);
    geo.translate(0, 0, -height / 2);
    return geo;
  }, []);

  useFrame(() => {
    if (!meshRef.current) return;
    const travelProgress = progress;
    
    // === COLOR LOGIC ===
    // Start: Intense Bright Yellow
    // End (No Aniso): Bright Red
    const startColor = new THREE.Color('#FFFF00'); 
    const endColor = new THREE.Color('#FF3333');
    
    // Planck Palette Colors
    const cColdDeep = new THREE.Color('#001060'); // Deep Navy Blue
    const cColdMid = new THREE.Color('#33ccff');  // Bright Cyan/Light Blue
    const cHotMid = new THREE.Color('#ffcc00');   // Bright Yellow/Orange
    const cHotDeep = new THREE.Color('#aa0000');  // Dark Red

    // Accelerated color transition: Reach end color by 70% progress (approx 10,000 M years)
    // 1 / 0.7 approx 1.4. We use 1.5 to be safe.
    const colorProgress = Math.min(1, travelProgress * 1.5);

    photonData.forEach((p, i) => {
      // NOTE: Strictly use p.vec (perfect sphere) to ensure equidistance at t=0
      const startPos = p.vec;
      
      // TARGET LOGIC:
      // Instead of going to 0,0,0, we go to a small sphere of radius 0.15 around the center.
      // This ensures that at t=1, the photons form a visible cluster/sphere of color.
      const targetPos = startPos.clone().normalize().multiplyScalar(0.15);

      dummy.position.copy(startPos).lerp(targetPos, travelProgress);
      
      const particleSize = 0.05 * (1 + travelProgress * 0.5);
      dummy.scale.set(particleSize, particleSize, particleSize);
      dummy.lookAt(0,0,0); 
      dummy.updateMatrix();
      
      meshRef.current!.setMatrixAt(i, dummy.matrix);

      // Color Interpolation
      const instanceColor = startColor.clone().lerp(endColor, colorProgress);

      if (showAnisotropies) {
          const val = p.anisotropy; // Range -1 to 1
          
          if (val < 0) {
             // Cold Sector: Dark Blue (-1) -> Cyan (0)
             // We remap -1..0 to 0..1 for lerping
             const t = (val + 1); 
             // Use power to tweak the gradient curve to match image contrast
             instanceColor.copy(cColdDeep).lerp(cColdMid, Math.pow(t, 0.8));
          } else {
             // Hot Sector: Yellow (0) -> Dark Red (1)
             const t = val;
             instanceColor.copy(cHotMid).lerp(cHotDeep, t);
          }
      }

      meshRef.current!.setColorAt(i, instanceColor);

      // Update Tails - SAME COLOR
      if (showTails && tailMeshRef.current) {
         tailMeshRef.current.setColorAt(i, instanceColor);
         const dist = dummy.position.length();
         
         let fadeScale = 1.0;
         if (dist < 1.5) {
             fadeScale = Math.max(0, (dist - 0.3) / 1.2); 
             fadeScale = fadeScale * fadeScale * fadeScale;
         }

         const tailWidth = particleSize * fadeScale; 
         const tailLength = fadeScale; 
         
         dummy.scale.set(tailWidth, tailWidth, tailWidth * tailLength);
         dummy.updateMatrix();
         tailMeshRef.current.setMatrixAt(i, dummy.matrix);
      }

      if (i === HERO_PHOTON_INDEX && labelGroupRef.current) {
        labelGroupRef.current.position.copy(dummy.position);
      }
    });
    
    meshRef.current.instanceMatrix.needsUpdate = true;
    meshRef.current.instanceColor!.needsUpdate = true;
    if (tailMeshRef.current && showTails) {
        tailMeshRef.current.instanceMatrix.needsUpdate = true;
        tailMeshRef.current.instanceColor!.needsUpdate = true;
    }
  });

  return (
    <>
      <instancedMesh 
        ref={meshRef} 
        args={[undefined, undefined, PHOTON_COUNT]} 
        onPointerOver={() => {
          const z = calculateRedshift(scaleFactor);
          const T = calculateTemperature(z);
          const fluctuation = (Math.random() - 0.5) * (T / 10000); 
          onHover(z, T + fluctuation);
        }}
        onPointerOut={() => onHover(0, 0)}
      >
        <sphereGeometry args={[1, 8, 8]} />
        <meshBasicMaterial toneMapped={false} transparent opacity={0.8} />
      </instancedMesh>

      {showTails && (
        <instancedMesh ref={tailMeshRef} args={[undefined, undefined, PHOTON_COUNT]} geometry={tailGeometry}>
            <meshBasicMaterial transparent opacity={0.4} blending={THREE.AdditiveBlending} depthWrite={false} />
        </instancedMesh>
      )}
      
      {showLabels && (
        <group ref={labelGroupRef}>
            <Html 
            zIndexRange={[100, 0]} 
            style={{ pointerEvents: 'auto' }} 
            >
            <div className="relative">
                <svg className="overflow-visible absolute top-0 left-0 pointer-events-none" width="1" height="1">
                    <defs>
                        <filter id="glow-line" x="-20%" y="-20%" width="140%" height="140%">
                            <feGaussianBlur stdDeviation="2" result="blur" />
                            <feComposite in="SourceGraphic" in2="blur" operator="over" />
                        </filter>
                    </defs>
                    <path 
                        d="M0,0 L30,-50 L240,-50" 
                        stroke="#38bdf8" 
                        strokeWidth="2" 
                        fill="none" 
                        filter="url(#glow-line)"
                        strokeOpacity="0.8"
                    />
                    <circle cx="0" cy="0" r="3" fill="white" filter="url(#glow-line)" />
                </svg>

                <div 
                    className="absolute" 
                    style={{ 
                        left: '30px', 
                        top: '-50px', 
                        transform: 'translateY(-50%)' 
                    }}
                >
                    <div className="bg-slate-950/80 backdrop-blur-md border border-sky-500/30 px-4 py-3 rounded-lg shadow-[0_4px_20px_rgba(0,0,0,0.6)] ml-2 text-left min-w-[240px] relative overflow-hidden group">
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-sky-500/10 to-transparent -translate-x-full animate-[shimmer_3s_infinite]"></div>
                        <div className="flex items-center gap-2 mb-1.5 border-b border-sky-500/20 pb-1.5 relative z-10">
                            <div className="w-2 h-2 bg-sky-400 rounded-full shadow-[0_0_8px_#38bdf8] animate-pulse"></div>
                            <span className="text-[10px] text-sky-400 font-bold uppercase tracking-widest">Fotón CMB</span>
                        </div>
                        <h3 className="text-sm font-semibold text-white leading-snug relative z-10 mb-1">
                            Radiación de fondo cósmico<br/>de microondas (CMB)
                        </h3>
                        
                        {isNearEnd && (
                            <button 
                                onClick={(e) => {
                                    e.stopPropagation();
                                    onOpen360();
                                }}
                                className="mt-2 w-full py-1.5 bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold rounded shadow-lg shadow-sky-900/50 flex items-center justify-center gap-2 transition-all animate-in fade-in slide-in-from-top-2 duration-500"
                            >
                                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                                Ver en 360° / VR
                            </button>
                        )}
                    </div>
                </div>
            </div>
            </Html>
        </group>
      )}
    </>
  );
};

// === Receding Photons (Stopped at Emission - Matter/Electrons Left Behind) ===
const RecedingPhotons: React.FC<{ 
  initialRadius: number; 
  count: number;
  opacity: number;
  showLabels: boolean;
  showTails: boolean;
  progress: number;
}> = ({ initialRadius, count, opacity, showLabels, showTails, progress }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const tailMeshRef = useRef<THREE.InstancedMesh>(null);
  const materialRef = useRef<THREE.MeshBasicMaterial>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);

  const initialPositions = useMemo(() => {
    const positions = [];
    for (let i = 0; i < count; i++) {
      const phi = Math.acos(-1 + (2 * i) / count);
      const theta = Math.sqrt(count * Math.PI) * phi;
      const x = initialRadius * Math.sin(phi) * Math.cos(theta);
      const y = initialRadius * Math.sin(phi) * Math.sin(theta);
      const z = initialRadius * Math.cos(phi);
      positions.push(new THREE.Vector3(x, y, z));
    }
    return positions;
  }, [count, initialRadius]);

  const tailGeometry = useMemo(() => {
    const height = 5.25; 
    const geo = new THREE.CylinderGeometry(0, 0.4, height, 8);
    geo.rotateX(-Math.PI / 2); 
    geo.translate(0, 0, -height / 2); 
    return geo;
  }, []);

  useFrame((state) => {
    if (!meshRef.current) return;
    
    // === COLOR TRANSITION LOGIC ===
    // Start: Intense Bright Yellow (#FFFF00)
    // End: Intense Red (#FF0000)
    const startColor = new THREE.Color('#FFFF00');
    const endColor = new THREE.Color('#FF0000');
    
    // Accelerated color transition: Reach end color by 70% progress
    const colorProgress = Math.min(1, progress * 1.5);
    const meshColor = startColor.clone().lerp(endColor, colorProgress);

    if (materialRef.current) {
        materialRef.current.opacity = opacity; // Keep opacity steady for receding (as requested implies only intermediate loses opacity)
    }

    const time = state.clock.getElapsedTime();
    const currentScale = 1 + (progress * 0.1);
    
    // Tail Growth Logic:
    // Grow up to 5x proportionally with distance
    const tailGrowthFactor = 1 + (progress * 4); // 1 + 4 = 5x
    
    // Wave damping factor: 0 at progress=0, 1 at progress=0.1+
    // Ensures perfect sphere at t=0
    const waveDamping = Math.min(1, progress * 10);

    initialPositions.forEach((pos, i) => {
      dummy.position.copy(pos).multiplyScalar(currentScale);
      dummy.position.y += Math.sin(time + i) * 0.02 * waveDamping; // Dampened wave

      const particleSize = 0.04;
      dummy.scale.set(particleSize, particleSize, particleSize);
      dummy.lookAt(0,0,0);
      dummy.updateMatrix();
      
      meshRef.current!.setMatrixAt(i, dummy.matrix);
      meshRef.current!.setColorAt(i, meshColor);

      if (showTails && tailMeshRef.current) {
          tailMeshRef.current.setColorAt(i, meshColor); // Ensure same color
          
          dummy.scale.set(particleSize, particleSize, particleSize * tailGrowthFactor);
          dummy.updateMatrix();
          tailMeshRef.current.setMatrixAt(i, dummy.matrix);
      }
    });
    meshRef.current.instanceMatrix.needsUpdate = true;
    if (meshRef.current.instanceColor) meshRef.current.instanceColor.needsUpdate = true;
    if (tailMeshRef.current && showTails) {
        tailMeshRef.current.instanceMatrix.needsUpdate = true;
        tailMeshRef.current.instanceColor!.needsUpdate = true;
    }
  });

  return (
    <>
      <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
        <sphereGeometry args={[1, 6, 6]} />
        <meshBasicMaterial ref={materialRef} transparent opacity={opacity} depthWrite={false} />
      </instancedMesh>
      
      {showTails && (
        <instancedMesh ref={tailMeshRef} args={[undefined, undefined, count]} geometry={tailGeometry}>
            <meshBasicMaterial transparent opacity={0.4} blending={THREE.AdditiveBlending} depthWrite={false} />
        </instancedMesh>
      )}

      {showLabels && (
        <Billboard position={[0, (-initialRadius * (1 + progress * 0.1)) - 1, 0]}>
           <Text fontSize={0.4} color="#ef4444" outlineColor="#000" outlineWidth={0.02}>
             Punto de Emisión (Recesión)
           </Text>
        </Billboard>
      )}
    </>
  );
};

// === Intermediate Photons (Equidistant Layer) ===
const IntermediatePhotons: React.FC<{ 
  initialRadius: number; 
  visualGrowth: number;
  progress: number;
  count: number;
  opacity: number;
  showLabels: boolean;
  showTails: boolean;
}> = ({ initialRadius, visualGrowth, progress, count, opacity, showLabels, showTails }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const tailMeshRef = useRef<THREE.InstancedMesh>(null);
  const materialRef = useRef<THREE.MeshBasicMaterial>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);

  const initialPositions = useMemo(() => {
    const positions = [];
    for (let i = 0; i < count; i++) {
      const phi = Math.acos(-1 + (2 * i) / count);
      const theta = Math.sqrt(count * Math.PI) * phi;
      const x = initialRadius * Math.sin(phi) * Math.cos(theta);
      const y = initialRadius * Math.sin(phi) * Math.sin(theta);
      const z = initialRadius * Math.cos(phi);
      positions.push(new THREE.Vector3(x, y, z));
    }
    return positions;
  }, [count, initialRadius]);

  const tailGeometry = useMemo(() => {
    const height = 5.25;
    const geo = new THREE.CylinderGeometry(0, 0.4, height, 8);
    geo.rotateX(-Math.PI / 2);
    geo.translate(0, 0, -height / 2);
    return geo;
  }, []);

  useFrame(() => {
    if (!meshRef.current) return;
    
    // === COLOR & OPACITY TRANSITION ===
    // Start: Yellow (#FFFF00)
    // End: Red (#FF0000)
    const startColor = new THREE.Color('#FFFF00');
    const endColor = new THREE.Color('#FF0000');
    
    // Accelerated color transition: Reach end color by 70% progress
    const colorProgress = Math.min(1, progress * 1.5);
    const meshColor = startColor.clone().lerp(endColor, colorProgress);

    // Opacity Fade: Loses 50% opacity by end (1.0 -> 0.5 factor relative to base opacity)
    if (materialRef.current) {
        materialRef.current.opacity = opacity * (1 - progress * 0.5);
    }

    // Tail Growth: Up to 10x
    const tailGrowthFactor = 1 + (progress * 9); // 1 + 9 = 10x

    const surfaceRadius = initialRadius * visualGrowth;
    const midRadius = (initialRadius + surfaceRadius) / 2;
    const midScale = midRadius / initialRadius;

    initialPositions.forEach((pos, i) => {
      dummy.position.copy(pos).multiplyScalar(midScale);
      
      const particleSize = 0.045;
      dummy.scale.set(particleSize, particleSize, particleSize);
      dummy.lookAt(0,0,0);
      dummy.updateMatrix();
      
      meshRef.current!.setMatrixAt(i, dummy.matrix);
      meshRef.current!.setColorAt(i, meshColor);

      if (showTails && tailMeshRef.current) {
        tailMeshRef.current.setColorAt(i, meshColor);
        // Stretched tail
        dummy.scale.set(particleSize, particleSize, particleSize * tailGrowthFactor);
        dummy.updateMatrix();
        tailMeshRef.current.setMatrixAt(i, dummy.matrix);
      }
    });

    meshRef.current.instanceMatrix.needsUpdate = true;
    if (meshRef.current.instanceColor) meshRef.current.instanceColor.needsUpdate = true;
    if (tailMeshRef.current && showTails) {
        tailMeshRef.current.instanceMatrix.needsUpdate = true;
        tailMeshRef.current.instanceColor!.needsUpdate = true;
    }
  });

  return (
    <>
      <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
        <sphereGeometry args={[1, 6, 6]} />
        <meshBasicMaterial ref={materialRef} color="#ffffff" transparent opacity={opacity} depthWrite={false} />
      </instancedMesh>
      
      {showTails && (
        <instancedMesh ref={tailMeshRef} args={[undefined, undefined, count]} geometry={tailGeometry}>
            <meshBasicMaterial transparent opacity={0.4} blending={THREE.AdditiveBlending} depthWrite={false} />
        </instancedMesh>
      )}
    </>
  );
};

// === Primordial Plasma (Beyond LSS) ===
const PrimordialPlasma: React.FC<{ 
  initialRadius: number; 
  expansionFactor: number;
  progress: number;
  count: number;
  showLabels: boolean;
}> = ({ initialRadius, expansionFactor, progress, count, showLabels }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);

  const colors = useMemo(() => {
    const c = [];
    const palette = [
      new THREE.Color("#172554"),
      new THREE.Color("#1e3a8a"),
      new THREE.Color("#334155"),
      new THREE.Color("#475569"),
    ];
    for (let i = 0; i < count; i++) {
      c.push(palette[Math.floor(Math.random() * palette.length)]);
    }
    return c;
  }, [count]);

  const initialOffsets = useMemo(() => {
    const offsets = [];
    for (let i = 0; i < count; i++) {
      const phi = Math.acos(-1 + (2 * i) / count);
      const theta = Math.sqrt(count * Math.PI) * phi;
      const depth = 1.05 + Math.random() * 0.5; 
      const x = Math.sin(phi) * Math.cos(theta);
      const y = Math.sin(phi) * Math.sin(theta);
      const z = Math.cos(phi);
      offsets.push({ vec: new THREE.Vector3(x, y, z), depth });
    }
    return offsets;
  }, [count]);

  const lssRadius = initialRadius * expansionFactor;
  const fadeDuration = 0.05;
  const fadeFactor = Math.max(0, 1 - (progress / fadeDuration));
  const particleOpacity = 0.35 * fadeFactor;
  const labelOpacity = fadeFactor;

  useFrame((state) => {
    if (!meshRef.current) return;
    const time = state.clock.getElapsedTime();

    initialOffsets.forEach((offset, i) => {
      const currentDistance = lssRadius * offset.depth;
      dummy.position.copy(offset.vec).multiplyScalar(currentDistance);
      
      const jitterAmount = 0.05 * expansionFactor;
      dummy.position.x += Math.sin(time * 5 + i) * jitterAmount;
      dummy.position.y += Math.cos(time * 3 + i) * jitterAmount;
      dummy.position.z += Math.sin(time * 4 + i) * jitterAmount;

      const particleSize = 0.08 * expansionFactor;
      dummy.scale.set(particleSize, particleSize, particleSize);
      dummy.updateMatrix();
      
      meshRef.current!.setMatrixAt(i, dummy.matrix);
      meshRef.current!.setColorAt(i, colors[i]);
    });
    
    meshRef.current.instanceMatrix.needsUpdate = true;
    if (meshRef.current.instanceColor) meshRef.current.instanceColor.needsUpdate = true;
  });

  if (fadeFactor <= 0.01) return null;

  return (
    <>
      <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
        <sphereGeometry args={[1, 6, 6]} />
        <meshBasicMaterial transparent opacity={particleOpacity} depthWrite={false} />
      </instancedMesh>
      
      {showLabels && (
        <Billboard position={[lssRadius * 1.5, lssRadius * 0.5, 0]}>
           <Text
              fontSize={Math.max(1, lssRadius * 0.08)} 
              color="#94a3b8" 
              fillOpacity={labelOpacity}
              outlineColor="#000000"
              outlineWidth={0.02}
              outlineOpacity={labelOpacity}
              anchorX="left"
              font="https://fonts.gstatic.com/s/inter/v12/UcCO3FwrK3iLTeHuS_fvQtMwCp50KnMw2boKoduKmMEVuLyfAZ9hjp-Ek-_EeA.woff"
            >
              Plasma Primordial Primigenio
            </Text>
        </Billboard>
      )}
    </>
  );
};

// The Grid represents the Surface of Last Scattering container
const ExpandingGrid: React.FC<{ visualGrowth: number; show: boolean; showLabels: boolean }> = ({ visualGrowth, show, showLabels }) => {
  if (!show) return null;
  
  return (
    <group scale={[visualGrowth, visualGrowth, visualGrowth]}>
      {/* 1. Surface of Last Scattering (The distinct "Wall" that moves away) */}
      <mesh>
        <sphereGeometry args={[INITIAL_UNIVERSE_RADIUS, 32, 32]} />
        <meshBasicMaterial color="#334155" wireframe transparent opacity={0.2} side={THREE.BackSide} />
      </mesh>
      
      {showLabels && (
        <Billboard position={[0, INITIAL_UNIVERSE_RADIUS + 0.5, 0]}>
            <Text fontSize={0.5} color="#94a3b8" outlineColor="#000" outlineWidth={0.02}>
              Superficie de Última Dispersión
            </Text>
        </Billboard>
      )}
    </group>
  );
};

// Component: Observable Universe Sphere
const ObservableUniverseSphere: React.FC<{ show: boolean; showLabels: boolean; progress: number }> = ({ show, showLabels, progress }) => {
  if (!show) return null;
  // NOTE: Radius must exactly match INITIAL_UNIVERSE_RADIUS to ensure coincidence at t=0
  const radius = INITIAL_UNIVERSE_RADIUS; 
  // Grows from 1.0 (start) to 1.1 (end) = 10% growth
  const scale = 1 + (progress * 0.1); 

  return (
    <group scale={[scale, scale, scale]}>
      <mesh>
        <sphereGeometry args={[radius, 64, 64]} />
        <meshBasicMaterial 
          color="#a5b4fc" // Indigo-200/300
          transparent 
          opacity={0.08} // Very low opacity
          side={THREE.DoubleSide}
          depthWrite={false}
        />
      </mesh>
      {showLabels && (
        <Billboard position={[0, radius - 1, 0]}>
          <Text fontSize={0.4} color="#818cf8" outlineColor="#000" outlineWidth={0.02}>
            Universo Observable
          </Text>
        </Billboard>
      )}
    </group>
  );
};

// Component: Observer (Center)
const Observer: React.FC<{ showLabels: boolean }> = ({ showLabels }) => {
  return (
    <group position={[0, 0, 0]}>
      <mesh>
        {/* Reduced Observer Radius from 0.15 to 0.05 */}
        <sphereGeometry args={[0.05, 32, 32]} />
        <meshBasicMaterial color="#38bdf8" />
      </mesh>
      {showLabels && (
        <Billboard position={[0, 0.4, 0]}>
          <Text fontSize={0.3} color="#38bdf8" outlineColor="#000" outlineWidth={0.02}>
            Observador
          </Text>
        </Billboard>
      )}
    </group>
  );
};

// Camera Controller
const CameraController: React.FC<{ zoomLevel: number; onZoomChange?: (zoom: number) => void }> = ({ zoomLevel, onZoomChange }) => {
  const { camera } = useThree();
  const controlsRef = useRef<any>(null);
  
  useEffect(() => {
    if (!camera || !controlsRef.current) return;
    const currentDist = camera.position.length();
    if (Math.abs(currentDist - zoomLevel) > 1) {
        const currentDir = new THREE.Vector3().copy(camera.position).normalize();
        const safeZoom = Math.max(1, Math.min(80, zoomLevel));
        camera.position.copy(currentDir.multiplyScalar(safeZoom));
        controlsRef.current.update();
    }
  }, [zoomLevel, camera]);

  return (
    <OrbitControls 
        ref={controlsRef}
        minDistance={1} 
        maxDistance={80} 
        onChange={(e) => {
            if (e?.target?.object?.position && onZoomChange) {
                const dist = e.target.object.position.length();
                onZoomChange(dist);
            }
        }}
    />
  );
};

const SceneContent: React.FC<SimulationProps> = ({ state, onHoverData, onZoomChange, onOpen360 }) => {
  const scaleFactor = calculateScaleFactor(state.time);
  
  const geometricBase = 2.2;
  const frequencyDivisor = 1.5;
  const edgeTerm = Math.pow(geometricBase, INITIAL_UNIVERSE_RADIUS / frequencyDivisor) - 1;
  const visualGrowth = 1 + state.time * edgeTerm * 1.5;

  return (
    <>
      <CameraController zoomLevel={state.zoomLevel} onZoomChange={onZoomChange} />
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} intensity={1} />
      
      <Observer showLabels={state.showLabels} />
      
      <ExpandingGrid visualGrowth={visualGrowth} show={state.showComovingGrid} showLabels={state.showLabels} />
      
      {/* Spacetime Fabric (Geometric Expansion) */}
      <SpacetimeFabric 
        progress={state.time} 
        initialRadius={INITIAL_UNIVERSE_RADIUS} 
        show={state.showSpacetimeFabric} 
      />

      {/* New: Geodesic Metric Grid (Power Law Icosahedral Lattice) */}
      <GeodesicMetricGrid 
        progress={state.time}
        initialRadius={INITIAL_UNIVERSE_RADIUS}
        show={state.showAcceleratedGrid} 
      />
      
      <ObservableUniverseSphere 
        show={state.showObservableUniverse} 
        showLabels={state.showLabels} 
        progress={state.time}
      />

      {state.showPhotons && (
        <Photons 
          progress={state.time} 
          scaleFactor={scaleFactor} 
          showLabels={state.showLabels} 
          showTails={state.showPhotonTails} 
          showAnisotropies={state.showAnisotropies}
          onHover={onHoverData} 
          onOpen360={onOpen360}
        />
      )}

      {state.showRecedingPhotons && (
        <RecedingPhotons 
          initialRadius={INITIAL_UNIVERSE_RADIUS} 
          count={400}
          opacity={0.8}
          showLabels={state.showLabels}
          showTails={state.showPhotonTails}
          progress={state.time} // Scaled growth
        />
      )}

      {state.showIntermediatePhotons && (
        <IntermediatePhotons 
          initialRadius={INITIAL_UNIVERSE_RADIUS} 
          visualGrowth={visualGrowth}
          progress={state.time}
          count={400}
          opacity={0.8}
          showLabels={state.showLabels}
          showTails={state.showPhotonTails}
        />
      )}

      {state.showPrimordialPlasma && (
        <PrimordialPlasma 
          initialRadius={INITIAL_UNIVERSE_RADIUS} 
          expansionFactor={visualGrowth}
          progress={state.time} 
          count={800} 
          showLabels={state.showLabels}
        />
      )}
    </>
  );
};

const SimulationCanvas: React.FC<SimulationProps> = (props) => {
  return (
    <Canvas camera={{ position: [20, 15, 20], fov: 45 }} dpr={[1, 2]}>
      <SceneContent {...props} />
    </Canvas>
  );
};

export default SimulationCanvas;