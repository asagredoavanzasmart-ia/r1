import React, { useEffect, useState } from 'react';

interface IntroModalProps {
  onClose: () => void;
}

const IntroModal: React.FC<IntroModalProps> = ({ onClose }) => {
  const [isVisible, setIsVisible] = useState(false);

  // Fade-in effect on mount
  useEffect(() => {
    setIsVisible(true);
  }, []);

  const handleClose = () => {
    setIsVisible(false);
    // Wait for animation to finish before unmounting
    setTimeout(onClose, 500);
  };

  return (
    <div className={`fixed inset-0 z-[100] flex items-center justify-center p-4 transition-opacity duration-500 ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
      
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/95 backdrop-blur-md" />

      {/* Card Content - Centered */}
      <div className={`relative bg-slate-900/90 border border-slate-700/50 rounded-2xl max-w-2xl w-full p-8 md:p-12 shadow-2xl overflow-hidden flex flex-col items-center transform transition-all duration-700 ${isVisible ? 'scale-100 translate-y-0' : 'scale-95 translate-y-8'}`}>
         
         {/* Decorative Background Elements */}
         <div className="absolute top-0 right-0 w-96 h-96 bg-sky-500/10 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/3 pointer-events-none"></div>
         <div className="absolute bottom-0 left-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-[80px] translate-y-1/3 -translate-x-1/3 pointer-events-none"></div>

         <div className="relative z-10 flex flex-col items-center text-center h-full">
            
            {/* Header */}
            <div className="mb-8">
                <div className="w-20 h-1.5 bg-gradient-to-r from-transparent via-sky-500 to-transparent mb-6 mx-auto rounded-full"></div>
                <h2 className="text-4xl md:text-5xl font-bold text-white tracking-tight mb-2">
                    El Viaje de la Luz
                </h2>
                <span className="text-sm font-mono text-sky-400 uppercase tracking-widest">Simulación Cosmológica FLRW</span>
            </div>

            {/* Text Content */}
            <div className="space-y-6 text-slate-300 text-lg md:text-xl leading-relaxed font-light">
                <p>
                <strong className="text-white font-semibold">Cuando el universo apenas tenía unos 380.000 años</strong>, en un estado denso y ardiente, <strong className="text-sky-400 font-semibold">la luz conquistó su libertad</strong>.
                </p>
                
                <p>
                En ese instante de claridad, un vasto océano de fotones emprendió una odisea solitaria a través del vacío en expansión; un viaje ininterrumpido que se ha extendido por <strong className="text-white font-semibold">más de 13.800 M de años</strong>.
                </p>
                
                <p>
                Hoy, esos antiguos mensajeros terminan su travesía impactando contra nuestros detectores en la Tierra, dándonos el privilegio de <strong className="text-white font-semibold">mirar hacia el pasado más remoto</strong>.
                </p>
            </div>

            {/* Action Button */}
            <div className="mt-10">
                <button
                onClick={handleClose}
                className="group relative px-10 py-4 bg-transparent overflow-hidden rounded-full border border-sky-500/50 shadow-[0_0_20px_rgba(14,165,233,0.2)] hover:shadow-[0_0_30px_rgba(14,165,233,0.5)] transition-all duration-300"
                >
                <div className="absolute inset-0 w-0 bg-sky-600 transition-all duration-[250ms] ease-out group-hover:w-full opacity-100"></div>
                <span className="relative text-sky-300 group-hover:text-white font-bold text-xl tracking-wide flex items-center gap-3 transition-colors">
                    INICIAR SIMULACIÓN
                    <svg className="w-6 h-6 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                    </svg>
                </span>
                </button>
            </div>
         </div>

      </div>
    </div>
  );
};

export default IntroModal;