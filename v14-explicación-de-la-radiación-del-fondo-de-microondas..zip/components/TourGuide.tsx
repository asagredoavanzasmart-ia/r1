import React, { useState, useEffect, useRef } from 'react';

interface Step {
  target: string;
  title: string;
  content: string;
  position: 'top' | 'bottom' | 'left' | 'right' | 'center';
}

interface TourGuideProps {
  start: boolean;
  onFinish: () => void;
}

const steps: Step[] = [
  {
    target: 'center',
    title: 'Bienvenido al Explorador CMB',
    content: 'Esta herramienta interactiva te permite visualizar la evolución del universo y la propagación de la luz desde el Big Bang hasta hoy. Vamos a ver cómo funciona.',
    position: 'center'
  },
  {
    target: '#tour-timeline',
    title: 'Línea de Tiempo Cósmica',
    content: 'Desliza esta barra para viajar en el tiempo. Desde la Recombinación (t=0) hasta el Presente (t=1). Observa cómo cambia la escala del universo.',
    position: 'top'
  },
  {
    target: '#tour-data',
    title: 'Datos en Vivo',
    content: 'Aquí verás el Redshift (z) y la Temperatura (T) en tiempo real. Pasa el mouse sobre los fotones (las partículas brillantes) para ver sus datos específicos.',
    position: 'right' // On desktop typically
  },
  {
    target: '#tour-zoom',
    title: 'Control de Cámara',
    content: 'Usa este deslizador o la rueda de tu mouse para hacer Zoom. Acércate para ver detalles o aléjate para ver la estructura a gran escala.',
    position: 'left'
  },
  {
    target: '#tour-toggles',
    title: 'Capas de Visualización',
    content: 'Activa o desactiva elementos: la cuadrícula de expansión, los diferentes tipos de fotones o el tejido espacio-temporal.',
    position: 'top'
  },
  {
    target: '#tour-media',
    title: 'Imágenes Reales',
    content: 'Accede a imágenes reales del satélite Planck, mapas logarítmicos y modelos 3D de la NASA para comparar la simulación con la realidad.',
    position: 'right'
  },
  {
    target: '#tour-chat',
    title: 'Asistente IA',
    content: '¿Tienes dudas sobre física? Habla con nuestro Astrónomo IA impulsado por Gemini para explicaciones detalladas.',
    position: 'left'
  },
  {
    target: '#tour-history',
    title: 'Línea Histórica',
    content: 'Explora los hitos científicos clave, desde las predicciones de 1948 hasta los descubrimientos de los satélites modernos.',
    position: 'left'
  },
  {
    target: '#tour-context',
    title: 'Contexto Científico',
    content: 'Abre este panel para leer la explicación académica y las ecuaciones detrás de esta simulación.',
    position: 'top'
  }
];

const TourGuide: React.FC<TourGuideProps> = ({ start, onFinish }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [targetRect, setTargetRect] = useState<DOMRect | null>(null);
  const [windowSize, setWindowSize] = useState({ w: window.innerWidth, h: window.innerHeight });

  useEffect(() => {
    const handleResize = () => setWindowSize({ w: window.innerWidth, h: window.innerHeight });
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (!start) return;

    // Find target
    const step = steps[currentStep];
    if (step.target === 'center') {
      // Create a virtual rect in the center
      const w = 400;
      const h = 200;
      setTargetRect({
        top: (window.innerHeight - h) / 2,
        left: (window.innerWidth - w) / 2,
        width: w,
        height: h,
        right: (window.innerWidth + w) / 2,
        bottom: (window.innerHeight + h) / 2,
        x: (window.innerWidth - w) / 2,
        y: (window.innerHeight - h) / 2,
        toJSON: () => {}
      } as DOMRect);
    } else {
      const el = document.querySelector(step.target);
      if (el) {
        const rect = el.getBoundingClientRect();
        // Add some padding
        const padding = 10;
        setTargetRect({
          top: rect.top - padding,
          left: rect.left - padding,
          width: rect.width + padding * 2,
          height: rect.height + padding * 2,
          right: rect.right + padding,
          bottom: rect.bottom + padding,
          x: rect.x - padding,
          y: rect.y - padding,
          toJSON: () => {}
        } as DOMRect);
        
        // Ensure element is visible
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } else {
        // Fallback if element not found (e.g., hidden in mobile)
        // Just skip to next or show centered
        console.warn(`Tour target ${step.target} not found`);
      }
    }
  }, [currentStep, start, windowSize]);

  if (!start || !targetRect) return null;

  const step = steps[currentStep];
  const isLast = currentStep === steps.length - 1;

  const next = () => {
    if (isLast) {
      onFinish();
    } else {
      setCurrentStep(prev => prev + 1);
    }
  };

  const prev = () => {
    if (currentStep > 0) setCurrentStep(prev => prev - 1);
  };

  // SVG Path for the "Hole" (Spotlight effect)
  // M 0 0 H width V height H 0 Z  -> Outer Box (Full Screen)
  // M x y h w v h z -> Inner Box (Cutout, Counter-Clockwise to subtract)
  const path = `
    M 0 0 
    H ${windowSize.w} 
    V ${windowSize.h} 
    H 0 
    Z 
    M ${targetRect.left} ${targetRect.top} 
    V ${targetRect.bottom} 
    H ${targetRect.right} 
    V ${targetRect.top} 
    Z
  `;

  // Calculate Tooltip Position
  let tooltipStyle: React.CSSProperties = {};
  const tooltipWidth = 320;
  
  // Center specific logic
  if (step.target === 'center') {
      tooltipStyle = {
          top: targetRect.bottom + 20,
          left: windowSize.w / 2 - tooltipWidth / 2
      };
  } else {
      // Basic positioning logic
      if (step.position === 'top') {
          tooltipStyle = { top: targetRect.top - 180, left: targetRect.left + (targetRect.width / 2) - (tooltipWidth/2) };
      } else if (step.position === 'bottom') {
          tooltipStyle = { top: targetRect.bottom + 20, left: targetRect.left + (targetRect.width / 2) - (tooltipWidth/2) };
      } else if (step.position === 'left') {
          tooltipStyle = { top: targetRect.top, left: targetRect.left - tooltipWidth - 20 };
      } else if (step.position === 'right') {
          tooltipStyle = { top: targetRect.top, left: targetRect.right + 20 };
      }

      // Boundary Checks (Keep on screen)
      if ((tooltipStyle.left as number) < 10) tooltipStyle.left = 10;
      if ((tooltipStyle.left as number) + tooltipWidth > windowSize.w) tooltipStyle.left = windowSize.w - tooltipWidth - 10;
      if ((tooltipStyle.top as number) < 10) tooltipStyle.top = targetRect.bottom + 10; // Flip to bottom if too high
      if ((tooltipStyle.top as number) > windowSize.h - 150) tooltipStyle.top = targetRect.top - 180; // Flip to top if too low
  }

  return (
    <div className="fixed inset-0 z-[200] pointer-events-auto">
      {/* SVG Overlay (The Shadow) */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none transition-all duration-500 ease-in-out">
        <path d={path} fill="rgba(0, 0, 0, 0.75)" fillRule="evenodd" />
        {/* Animated Stroke around the target */}
        <rect 
            x={targetRect.left} 
            y={targetRect.top} 
            width={targetRect.width} 
            height={targetRect.height} 
            fill="none" 
            stroke="#38bdf8" 
            strokeWidth="2"
            rx="8"
            className="animate-pulse"
        />
      </svg>

      {/* Tooltip Card */}
      <div 
        className="absolute flex flex-col p-6 bg-slate-900 border border-sky-500/50 rounded-xl shadow-[0_0_50px_rgba(0,0,0,0.8)] transition-all duration-500 ease-out"
        style={{ ...tooltipStyle, width: tooltipWidth }}
      >
        <div className="flex justify-between items-start mb-3">
             <h3 className="text-lg font-bold text-white">{step.title}</h3>
             <span className="text-xs font-mono text-slate-500 bg-slate-800 px-2 py-1 rounded">
                 {currentStep + 1} / {steps.length}
             </span>
        </div>
        
        <p className="text-sm text-slate-300 mb-6 leading-relaxed">
            {step.content}
        </p>

        <div className="flex justify-between items-center mt-auto">
            <button 
                onClick={onFinish}
                className="text-xs text-slate-500 hover:text-white underline"
            >
                Saltar
            </button>
            
            <div className="flex gap-2">
                <button 
                    onClick={prev}
                    disabled={currentStep === 0}
                    className={`px-3 py-1.5 rounded text-xs font-medium border border-slate-700 ${currentStep === 0 ? 'opacity-30 cursor-not-allowed text-slate-500' : 'text-slate-300 hover:bg-slate-800'}`}
                >
                    Anterior
                </button>
                <button 
                    onClick={next}
                    className="px-4 py-1.5 rounded text-xs font-bold bg-sky-600 hover:bg-sky-500 text-white shadow-lg shadow-sky-900/50 transition-all"
                >
                    {isLast ? 'Finalizar' : 'Siguiente'}
                </button>
            </div>
        </div>

        {/* Arrow Decoration (Decorative only, simplified) */}
        <div className="absolute w-3 h-3 bg-slate-900 border-l border-t border-sky-500/50 transform rotate-45 -top-1.5 left-6" />
      </div>
    </div>
  );
};

export default TourGuide;