
// Simplified FLRW Physics Constants and Calculators

export const COSMO_CONSTANTS = {
  z_recombination: 1100,
  T_now: 2.725, // Kelvin
  T_recombination: 3000, // Kelvin (approx)
  age_recombination: 380000, // Years
  age_now: 13800000000, // Years (13.8 Billion)
};

/**
 * Calculates the Scale Factor a(t) based on a simplified generic expansion model
 * mimicking a transition from matter-dominated to Lambda-dominated.
 * 
 * @param progress Normalized time 0 (Recombination) to 1 (Present)
 * @returns Scale factor 'a' (normalized such that a_present = 1)
 */
export const calculateScaleFactor = (progress: number): number => {
  // Recombination happened when universe was approx 1/1100th of current size.
  const a_start = 1 / (COSMO_CONSTANTS.z_recombination + 1);
  const a_end = 1.0;
  
  // Using a power law approx for visualization smoothness: a(t) ~ t^(2/3) roughly
  // We map the slider input (0-1) to the cosmic timeline.
  // Linear interpolation for the demo would be boring, let's use a slight curve.
  const timeCurve = Math.pow(progress, 0.7); 
  
  return a_start + (a_end - a_start) * timeCurve;
};

/**
 * Calculates the estimated age of the universe for the label
 * Maps progress 0-1 linearly between Recombination and Present
 * Formats: 
 * - < 1,000,000: "380k años"
 * - >= 1,000,000: "13.800 M años" (Millions)
 */
export const calculateUniverseAge = (progress: number): string => {
  const currentYears = COSMO_CONSTANTS.age_recombination + (COSMO_CONSTANTS.age_now - COSMO_CONSTANTS.age_recombination) * progress;
  
  if (currentYears < 1000000) {
    return `${Math.floor(currentYears / 1000)}k años`;
  } else {
    // Format as Millions (e.g. 13800000000 -> 13.800 M)
    const millions = currentYears / 1000000;
    // Use Spanish locale for correct thousands separator (dot)
    return `${millions.toLocaleString('es-ES', { maximumFractionDigits: 0 })} M años`;
  }
};

/**
 * Calculates Redshift z based on current scale factor
 * 1 + z = a(now) / a(t)
 */
export const calculateRedshift = (scaleFactor: number): number => {
  return (1.0 / scaleFactor) - 1;
};

/**
 * Calculates Temperature T(z)
 * T(z) = T0 * (1 + z)
 */
export const calculateTemperature = (z: number): number => {
  return COSMO_CONSTANTS.T_now * (1 + z);
};

/**
 * Returns a color based on temperature/redshift for visualization
 * High T (Recombination) -> Orange/White
 * Medium T -> Red
 * Low T (CMB Now) -> Faint Blue/Grey (Microwaves are invisible, represented symbolically)
 */
export const getPhotonColor = (z: number): string => {
  // Logarithmic scale for better visual transition
  if (z > 500) return '#ffaa00'; // Recombination glow (Orange/White)
  if (z > 100) return '#ff4500'; // Redshifting (Deep Red)
  if (z > 10) return '#8b0000'; // Dark Red/Infrared
  if (z > 1) return '#4b0082'; // Fading to invisible/radio
  return '#3b82f6'; // Present day microwave background (Symbolic Cold Blue)
};